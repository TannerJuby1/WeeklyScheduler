//
//  server.hpp
//  WeeklyScheduler
//
//  Created by Tanner Juby on 3/15/17.
//  Copyright © 2017 Juby. All rights reserved.
//

#ifndef server_hpp
#define server_hpp

#include <stdio.h>

#endif /* server_hpp */
