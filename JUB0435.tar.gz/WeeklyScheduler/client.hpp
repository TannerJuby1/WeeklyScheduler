//
//  client.hpp
//  WeeklyScheduler
//
//  Created by Tanner Juby on 3/15/17.
//  Copyright © 2017 Juby. All rights reserved.
//

#ifndef client_hpp
#define client_hpp

#include <stdio.h>

#endif /* client_hpp */
